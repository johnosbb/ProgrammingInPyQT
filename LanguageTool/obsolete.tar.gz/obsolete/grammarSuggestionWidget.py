
from tkinter.messagebox import QUESTION
from PyQt5.QtWidgets import (QApplication, QWidget, QLabel, QVBoxLayout,QTextEdit,QGridLayout,QSizePolicy,QFrame,QHBoxLayout)
from PyQt5.QtCore import Qt,QRect

DIALOG_WIDTH = 800
DIALOG_HEIGHT = 700


class GrammarSuggestionQWidget(QFrame):

    def __init__(self):
        super(GrammarSuggestionQWidget, self).__init__()
        self.initializeUI()

    def initializeUI(self):
        self.setWindowTitle('Grammar Suggestion Widget')
        self.setFrameShape(QFrame.StyledPanel)
        self.setFrameShadow(QFrame.Raised)
        self.setupWidgets()
        self.show()
        
    def setContext(self, context):
        self.context.setText(context  )
        
    def setSuggestions(self, suggestions):
        if(len(suggestions) > 1):
            for suggestion in suggestions:
                self.suggestion.setText(self.suggestion.toPlainText() + "," + suggestion)
        elif(len(suggestions) == 1):  
            self.suggestion.setText(suggestions[0])
        else:
            self.suggestion.setText("")
                
        
    def setCategoryDetails(self, details):        
        self.categoryDetailsLabel.setText(details)

    def setupWidgets(self):
        #self.setStyleSheet("border: 0px solid black")
        self.layout = QVBoxLayout()
        self.categoryLayout = QHBoxLayout()
        categoryLabel = QLabel("Category:")
        categoryLabel.setSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed)
        contextLabel = QLabel("Context:")
        self.categoryDetailsLabel = QLabel("Typo: Possible spelling mistake")
        self.context = QTextEdit()
        self.context.setReadOnly(True)
        self.context.setStyleSheet("padding-bottom: 3px;")
        #self.context.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Expanding)
        #self.context.setMinimumWidth(600)
        self.context.setMinimumHeight(200)
        #self.context.setStyleSheet("border: 1px solid blue;")
        self.suggestion = QTextEdit()
        self.suggestion.setReadOnly(True)
        #self.suggestion.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Expanding)
        #self.suggestion.setMinimumWidth(600)
        self.suggestion.setMinimumHeight(200)
        # self.suggestion.setStyleSheet("border: 1px solid blue;")
        suggestionsLabel = QLabel("Suggestion:")
        self.categoryLayout.addWidget(categoryLabel)
        self.categoryLayout.addWidget(self.categoryDetailsLabel)
        self.layout.addLayout(self.categoryLayout)
        self.layout.addWidget(contextLabel)
        self.layout.addWidget(self.context)
        self.layout.addWidget(suggestionsLabel)
        self.layout.addWidget(self.suggestion)
        # self.setStyleSheet("border: 1px solid black")

        self.setLayout(self.layout)

    